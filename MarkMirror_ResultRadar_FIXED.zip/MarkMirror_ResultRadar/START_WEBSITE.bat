@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo   MarkMirror - ResultRadar Rush
 echo =============================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10+ from https://www.python.org/downloads/
  echo During installation, select "Add Python to PATH".
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  py -m venv .venv
  if errorlevel 1 goto error
)
echo Installing required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error
echo.
echo Starting MarkMirror...
echo Keep this black window open while using the website.
echo Open http://127.0.0.1:5000 in your browser.
echo Press Ctrl+C here to stop the website.
start "" http://127.0.0.1:5000
".venv\Scripts\python.exe" app.py
pause
exit /b 0
:error
echo.
echo Setup failed. Check your internet connection and Python installation.
pause
exit /b 1
