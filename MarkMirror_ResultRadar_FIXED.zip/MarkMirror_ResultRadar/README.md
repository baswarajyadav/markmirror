# MarkMirror: ResultRadar Rush

A Flask + SQLite full-stack demo based on the supplied FSDD problem brief.

## Windows quick start
1. Install Python 3.10 or newer from https://www.python.org/downloads/ (select **Add Python to PATH** during installation).
2. Extract this ZIP file.
3. Open the `MarkMirror_ResultRadar` folder.
4. Double-click **START_WEBSITE.bat**. The first run installs Flask and may take a minute; an internet connection is required for package installation.
5. Keep the black terminal window open. Open `http://127.0.0.1:5000` in your browser.
6. Sign in using the demo account below.

Do **not** open `templates/index.html` directly and do not use VS Code Live Server. The page needs the Flask backend; opening the HTML alone causes a `Failed to fetch` error.

## Demo login
- Email: `admin@markmirror.com`
- Password: `Mirror@2026Demo!`

## Sample result
- Hall ticket: `22CSE104`
- Example SGPA: 8.85

## Features
- Hall-ticket result lookup and semester marksheet
- Credit-weighted SGPA/CGPA calculation
- Subject-wise pass/fail analytics and difficulty index
- Top 10 leaderboard and CGPA distribution histogram
- Browser print / Save as PDF marksheet
- Responsive dashboard and SQLite sample dataset (100+ synthetic student records)

## Manual start (optional)
From a terminal opened in this folder:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000`.

This is a locally runnable demo, not a publicly hosted website. The sample student records are fictional, not official university results. Chart.js loads from a public CDN, so charts need internet access.
