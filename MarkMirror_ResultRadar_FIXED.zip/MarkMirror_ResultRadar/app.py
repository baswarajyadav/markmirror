import os, sqlite3, secrets, random
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=Path(__file__).resolve().parent
DB=ROOT/'markmirror.sqlite3'
app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
SUBJECTS=[('Mathematics',4),('DBMS',4),('Operating Systems',3),('Computer Networks',3),('Software Engineering',3),('AI Lab',3)]
BRANCHES=['CSE','AIML','IT','ECE','CSD']
GRADE_POINTS=[(90,'O',10),(80,'A+',9),(70,'A',8),(60,'B+',7),(50,'B',6),(40,'C',5),(0,'F',0)]
def grade(m):
    for threshold,letter,point in GRADE_POINTS:
        if m>=threshold:return letter,point
    return 'F',0
def connect():
    c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init_db():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE COLLATE NOCASE, password TEXT, role TEXT DEFAULT 'admin');
        CREATE TABLE IF NOT EXISTS students(roll TEXT PRIMARY KEY,name TEXT,branch TEXT,marks TEXT);''')
        if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
            c.execute('INSERT INTO users(name,email,password) VALUES(?,?,?)',('Demo Admin','admin@markmirror.com',generate_password_hash('Mirror@2026Demo!')))
        if not c.execute('SELECT 1 FROM students LIMIT 1').fetchone():
            random.seed(17)
            names=['Aarav Mehta','Diya Sharma','Ishaan Rao','Ananya Reddy','Kabir Patel','Mira Nair','Vivaan Shah','Sana Khan','Reyansh Das','Tara Iyer','Arjun Kumar','Myra Joshi','Advik Singh','Aisha Thomas','Rohan Verma','Ira Gupta','Dev Malhotra','Kiara Bose','Neil Fernandes','Zoya Ali']
            for i in range(100):
                branch=BRANCHES[i%len(BRANCHES)]; roll=f'22{branch}{101+i:03d}'
                marks=[random.randint(35,99) for _ in SUBJECTS]
                name=names[i%len(names)] if i<20 else f'Student {i+1:03d}'
                c.execute('INSERT INTO students VALUES(?,?,?,?)',(roll,name,branch,','.join(map(str,marks))))
            # Required example from the brief: weighted SGPA = 8.85
            c.execute('INSERT OR REPLACE INTO students VALUES(?,?,?,?)',('22CSE104','Aarav Mehta','CSE','85,84,86,83,78,82'))
        c.commit()
def auth(f):
    @wraps(f)
    def w(*a,**k):
        if not session.get('uid'):return jsonify(error='Please sign in first.'),401
        return f(*a,**k)
    return w
def calc(row):
    marks=[int(x) for x in row['marks'].split(',')]
    items=[];weighted=credits=total=0;passed=0
    for (sub,cr),m in zip(SUBJECTS,marks):
        letter,point=grade(m);weighted+=cr*point;credits+=cr;total+=m;passed+=m>=40
        items.append({'subject':sub,'credits':cr,'marks':m,'grade':letter,'points':point,'status':'Pass' if m>=40 else 'Fail'})
    return {'roll':row['roll'],'name':row['name'],'branch':row['branch'],'subjects':items,'total':total,'out_of':600,'percentage':round(total/6,2),'sgpa':round(weighted/credits,2),'cgpa':round(weighted/credits,2),'passed':passed,'failed':6-passed}
@app.get('/')
def home():return render_template('index.html')
@app.post('/api/login')
def login():
    d=request.get_json() or {};email=str(d.get('email','')).strip();pw=str(d.get('password',''))
    with connect() as c:u=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
    if not u or not check_password_hash(u['password'],pw):return jsonify(error='Invalid email or password.'),401
    session.clear();session['uid']=u['id'];session['name']=u['name'];session['email']=u['email'];return jsonify(name=u['name'],email=u['email'])
@app.post('/api/logout')
@auth
def logout():session.clear();return jsonify(ok=True)
@app.get('/api/me')
def me():return (jsonify(name=session.get('name'),email=session.get('email')) if session.get('uid') else (jsonify(error='Not signed in'),401))
@app.get('/api/overview')
@auth
def overview():
    with connect() as c:rows=c.execute('SELECT * FROM students').fetchall()
    data=[calc(r) for r in rows];avg=round(sum(x['sgpa'] for x in data)/len(data),2)
    tops=sorted(data,key=lambda x:x['sgpa'],reverse=True)[:10]
    subjects=[]
    for i,(sub,cr) in enumerate(SUBJECTS):
        p=sum(1 for r in data if int(r['subjects'][i]['marks'])>=40);subjects.append({'subject':sub,'pass':p,'fail':len(data)-p,'rate':round(p/len(data)*100)})
    bins=[{'range':'0–5','count':sum(x['cgpa']<5 for x in data)},{'range':'5–6','count':sum(5<=x['cgpa']<6 for x in data)},{'range':'6–7','count':sum(6<=x['cgpa']<7 for x in data)},{'range':'7–8','count':sum(7<=x['cgpa']<8 for x in data)},{'range':'8–9','count':sum(8<=x['cgpa']<9 for x in data)},{'range':'9–10','count':sum(x['cgpa']>=9 for x in data)}]
    return jsonify(total=len(data),average=avg,pass_rate=round(sum(x['passed'] for x in data)/(len(data)*6)*100,1),toppers=tops,subjects=subjects,bins=bins,branches=BRANCHES)
@app.get('/api/result/<roll>')
@auth
def result(roll):
    with connect() as c:r=c.execute('SELECT * FROM students WHERE roll=?',(roll.upper(),)).fetchone()
    if not r:return jsonify(error='No result found for that hall ticket number.'),404
    return jsonify(result=calc(r))
if __name__=='__main__':
    init_db();app.run(debug=True)
else:init_db()
